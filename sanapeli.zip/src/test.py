import os,sys
print(sys.executable)
