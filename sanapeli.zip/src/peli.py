import kysymykset as ksms
import random,tkinter,sys,os,getpass
os.chdir('/home/'+getpass.getuser()+'/sanapeli/src')
k1 = ksms.ekavika(ksms.k[random.randint(0,len(ksms.k)-1)],random.randint(0,1))
print(k1[1])
print(input() in k1[0])
